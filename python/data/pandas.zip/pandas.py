import numpy as np
import pandas as pd
# creation of series from scalar values
s1 = pd.Series([10, 20, 30, 40, 50])
print(s1)

s2 = pd.Series(["Akshat", "Ansh", "Amritansh"], index=[3, 5, 1])
print(s2)

# creation of series from numpy arrays


arr1 = np.array([1, 2, 3, 4])
series3 = pd.Series(arr1)
print(series3)

s4 = pd.Series(arr1, index=["Jan", "Feb", "Mar", "Apr"])
print(s4)


# creation of series from Dictionary

dict1 = {'India': 'NewDelhi', 'UK': 'London',
         'Japan': 'Tokyo', 'France': 'Paris'}
s6 = pd.Series(dict1)
print(s6)

print(s6['India'])
print(s6[1])

#  Accessing Elements from Series

# Note:- index starts from 0

sno = pd.Series([10, 20, 30])
print(sno[2])

smnths = pd.Series([2, 3, 4], index=["Feb", "Mar", "Apr"])
print(smnths["Mar"])

print(s6[1:3])
print(s6['UK':'France'])

s7=pd.Series(['NewDelhi','WashingtonDC','London', 
'Paris'],index=['India', 'USA','UK','France'])
print(s7['USA':'France'])
print(s7[::-1])  # ----- REVERSE ORDER -----

seriesAlph = pd.Series(np.arange(10,16,1), 
index = ['a', 'b', 'c', 'd', 'e', 'f'])
print(seriesAlph)



# Mathematical Operation on Series

SeriesA=pd.Series([1,2,3,4,5],index=['a','b','c','d','e'])
SeriesB=pd.Series([-1,-2,-3,-4,-5],index=['a','b','c','d','e'])

#   Addition
print(SeriesA+SeriesB)
print(SeriesA.add(SeriesB,fill_value=0))

#   Subtraction
print(SeriesA-SeriesB)
print(SeriesA.sub(SeriesB, fill_value=1000))

#   multiplication
print(SeriesA*SeriesB)
print(SeriesA.mul(SeriesB, fill_value=0))
#   division
print(SeriesA.div(SeriesB, fill_value=0))

#   DataFrame

# Empty Dataframe
emptydf=pd.DataFrame()
print(emptydf)

#   Dataframe from NumPy Arrays
arr3=np.array([10,20,30])
arr4=np.array([-10,-20,-30,-40])
arr5=np.array([100,200,300])
npdf=pd.DataFrame([arr3,arr4,arr5],columns=['A','B','C','D'])
print(npdf)

#   Creation Of DataFrame using list  of Dictionaries
l1=[{'a':10, 'b':20},{'a':5,'b':10,'c':20}]
listdf=pd.DataFrame(l1)
print(listdf)

#   Creation of DataFrame using dictionaries of list

dicforest= {'State':['Assam','Delhi','Kerela'],
            'Garea':[78438,1483,38852],
            'VDF':[2797,6.72,1663]}
dfforest=pd.DataFrame(dicforest)
#print(dfforest)

dfforest1=pd.DataFrame(dicforest,columns=['State','Garea','VDF'],index=['A','B','C'])
print(dfforest1)


#   Creation of DataFrame using Series
SeriesC=pd.Series([1,2,3,4,5],index=['A','B','C','D','E'])
SeriesD=pd.Series([1000,2000,3000,4000,5000],index=['A','B','C','D','E'])
SeriesE=pd.Series([10,20,-10,-50,100],index =['z', 'y', 'a', 'c', 'e'])
seriesdf=pd.DataFrame([SeriesC,SeriesD,SeriesE],index=['A','B','C'])
print(seriesdf)
    
#   Creation of DataFrame from Dictionary of Series
ResultSheet={
        'Arnav': pd.Series([80,91,97],index=['Phy','Mat','Che']),
        'Akshat': pd.Series([99,92,93],index=['Phy','Mat','Che']),
        'Hardik': pd.Series([96,92,94],index=['Phy','Mat','Che']),
        'Siddarth': pd.Series([100,100,100],index=['Phy','Mat','Che']),
        'Bhavya': pd.Series([100,100,100],index=['Phy','Mat','Che']),
        'Keshav': pd.Series([99,97,98],index=['Phy','Mat','Che']),
        'Krishna': pd.Series([100,100,100],index=['Phy','Mat','Che']),
        'Ansh': pd.Series([98,97,92],index=['Phy','Mat','Che'])
    }

resultdf=pd.DataFrame(ResultSheet)
print(resultdf)


dictForUnion = { 
 'Series7' : pd.Series([1,2,3,4,5],index = ['a', 'b', 'c', 'd', 'e']),
 'Series8' : pd.Series([10,20,-10,-50,100],index = ['z', 'y', 'a', 'c', 'e']),
 'Series9' : pd.Series([10,20,-10,-50,100],index = ['z', 'y', 'a', 'c', 'e']) 
 }

uniondf=pd.DataFrame(dictForUnion)
print(uniondf)


resultdf['Preeti']=[89,78,76]
print(resultdf)

#   we can add a new row  using  DataFrame.loc[] method , so now let's do that

resultdf.loc['IP']=[90,92,93,94,82,87,93,89,92]
print(resultdf)

#   to drop any row
resultdf = resultdf.drop('IP',axis=0)
print(resultdf)

#   to drop any column
resultdf = resultdf.drop(['Arnav','Hardik'],axis=1)
print(resultdf)

#   Remaining row labels of a dataframe
resultdf=resultdf.rename({'Phy':'Sub1','Mat':'Sub2','Che':'Sub3'},axis='index')
print(resultdf)


#   Renaming column labels of a dataframe
resultdf=resultdf.rename({'Akshat':'Student1','Siddarth':'Student2','Bhavya':'Student3','Keshav':'Student4','Krishna':'Student5','Ansh':'Student6','Preeti':'Student7'},axis='columns')
print(resultdf)


#   Label Based Indexing
print(resultdf.loc['Sub1'])

#   When a single column label is passed, it returns the column as a Series
print(resultdf.loc[:,'Student1'])


#   Also, we can obtain the same result that is the marks of ‘Student1’ in all the subjects by using the command:
print(resultdf['Student1'])

#   To read more than one row from a DataFrame, a list of row labels is used as shown below. Note that using [[]] returns a DataFrame.
print(resultdf.loc[['Sub1', 'Sub2']])

#   boolean indexing
print(resultdf.loc['Sub1'] > 90)
print(resultdf.loc[:,'Student1']>90)

#   Accessing DataFrames Element through Slicing

print(resultdf.loc['Sub1': 'Sub2'])

print(resultdf.loc['Sub1': 'Sub2'])

print(resultdf.loc['Sub1': 'Sub2', 'Student1':'Student3'])

print(resultdf.loc['Sub1': 'Sub2',['Student1','Student3']])
print(resultdf.loc[[True, False, True]])

#   Attributes of DataFrames

ForestArea = {
 'Assam' :pd.Series([78438, 2797,10192, 15116],index = ['GeoArea', 'VeryDense', 'ModeratelyDense', 'OpenForest']),
 'Kerala' :pd.Series([ 38852, 1663, 9407, 9251],index = ['GeoArea' ,'VeryDense', 'ModeratelyDense', 'OpenForest']),
 'Delhi' :pd.Series([1483, 6.72, 56.24, 129.45], index = ['GeoArea', 'VeryDense', 'ModeratelyDense', 'OpenForest'])}

forestdf=pd.DataFrame(ForestArea)
print(forestdf)

#Attributes
print('Index of a dataframe\n',forestdf.index)
print('Columns of a DataFrame\n',forestdf.columns)
print('Size of a DataFrame\n',forestdf.size)
print('Dtype of a DataFrame\n',forestdf.dtypes)
print('Values of a DataFrame\n',forestdf.values)
print('Shape of a DataFrame\n',forestdf.shape)
print('Transpose of a DataFrame\n',forestdf.T)
print('Heads of a DataFrame\n',forestdf.head(2))
print('Tails of a DataFrame\n',forestdf.tail(3))

#Importing and Exporting of CSV FILE
marks=pd.read_csv("C:/Users/Akshat Mehta/Documents/marks.csv",sep =",", header=0)
print(marks)

resultdf.to_csv(path_or_buf='C:/Users/Akshat Mehta/Documents/resultdf.csv', sep=',')